## Student Name: Jayesh Naidu 
## Student ID: 1233830964 
## Date: 31-08-24


print("CPU Example: Calculating the sum of numbers from 1 to 20")
total_sum = 0

for i in range(1, 21):
    total_sum += i # Memory (storage)
    
print("Total Sum:", total_sum) # Output

# Simple I/O operation

user_input=input("Enter your name: ") # Input

print(f"Hey, {user_input}!") # Output