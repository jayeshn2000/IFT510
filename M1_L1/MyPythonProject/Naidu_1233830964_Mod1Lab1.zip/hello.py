## Student Name: Jayesh Naidu 
## Student ID: 1233830964 
## Date: 30-08-24

print('#'*20)
print("{}{}".format("Hello, ", "World!"))
print('#'*20)